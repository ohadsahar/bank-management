module.exports = {

  cors: {
    origin: '*',
    methods: 'POST, GET, DELETE, HEAD, PUT, PATCH, Authorization',
  },
};
